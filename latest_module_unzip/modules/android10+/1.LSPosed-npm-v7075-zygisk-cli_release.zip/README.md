
## Supported Versions

Android 8.1 ~ 14

#### Webroot cli from lsposed_mod